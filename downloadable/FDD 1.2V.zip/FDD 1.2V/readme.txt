TO RUN FUNKIN' FILE DOWNLOADER THE FOLDER NEEDS TO BE PLACED ON YOUR DESKTOP

A stable internet connection is need to download files from the internet.

Before running anything download HaxeFlixel, Haxe and Git from...

https://haxe.org/download/ <--- (HaxeFlixel is already in this)
https://git-scm.com

Run the Launcher.bat to start, if you want to cancel this just close the files.

If your windows is not on a C Drive you going to have to mainly change the script your self, right now theres no tutorials due to it not being popular.

DO NOT EDIT THE CODE IF YOU DONT KNOW WHAT YOUR DOING, EDITING THE CODE COULD BREAK IT

Thanks for Installing!